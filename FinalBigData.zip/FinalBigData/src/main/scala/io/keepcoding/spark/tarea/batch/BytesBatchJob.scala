package io.keepcoding.spark.tarea.batch

import java.time.OffsetDateTime
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import java.lang
import scala.collection.immutable.Range.Int

object BytesBatchJob {

  val spark: SparkSession = SparkSession
    .builder()
    .master("local[*]")
    .appName("Tarea final SQL Batch")
    .getOrCreate()

  import spark.implicits._

  def readFromStorage(storagePath: String, year_ : Integer, mes_ : Integer, dia_ : Integer): DataFrame = {
    spark
      .read
      .format("parquet")
      .load(s"${storagePath}/data")
      .filter(
        $"year" === year_ &&
          $"month" === mes_ &&
          $"day" === dia_
      )
  }

  def readUserMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame = {
    spark
      .read
      .format("jdbc")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .load()
  }

  def enrichUserWithMetadata(parquetDF: DataFrame, metadataDF: DataFrame): DataFrame = {
    parquetDF.as("parquet")
      .join(
        metadataDF.as("metadata"),
        $"parquet.id" === $"metadata.id"
      ).drop($"metadata.id")
  }

  def computeBytesByAntenna(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .select($"timestamp", $"antenna_id", $"bytes")
      .groupBy($"antenna_id", window($"timestamp", "1 hour"))
      .agg(
        sum($"bytes").as("value")
      )
      .select($"window.start".as("timestamp"), $"antenna_id".as("id"), $"value")
      .withColumn("type", lit("antenna_total_bytes"))

  }

  def computeBytesByApp(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .select($"timestamp", $"app", $"bytes")
      .groupBy($"app", window($"timestamp", "1 hour"))
      .agg(
        sum($"bytes").as("value")
      )
      .select($"window.start".as("timestamp"), $"app".as("id"), $"value")
      .withColumn("type", lit("app_total_bytes"))

  }

  def computeBytesByEmail(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .select($"timestamp", $"email", $"bytes")
      .groupBy($"email", window($"timestamp", "1 hour"))
      .agg(
        sum($"bytes").as("value")
      )
      .select($"window.start".as("timestamp"), $"email".as("id"), $"value")
      .withColumn("type", lit("mail_total_bytes"))

  }

  def computeBytesByQuota(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .select($"timestamp", $"email", $"bytes", $"name", $"quota")
      .groupBy($"email", window($"timestamp", "1 hour"))
      .agg(
        sum($"bytes").as("usage"),
        max($"quota").as("quota")
      )
      .select($"email", $"usage", $"quota", $"window.start".as("timestamp"))
      .filter($"usage" > $"quota")
  }


  def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Unit = {
    dataFrame
      .write
      .mode(SaveMode.Append)
      .format("jdbc")
      .option("driver", "org.postgresql.Driver")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .save()
  }


  def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Unit = {
    dataFrame
      .write
      .partitionBy("year", "month", "day", "hour")
      .format("parquet")
      .mode(SaveMode.Overwrite)
      .save(s"${storageRootPath}/historical")
  }

  def main(args: Array[String]): Unit = {
    val IpServer = "35.222.25.88"
    val url = s"jdbc:postgresql://$IpServer:5432/postgres"
    val username = "postgres"
    val password = "postgres"

    val year = 2022
    val month = 10
    val day = 31
    val parquetDF = readFromStorage("/tmp/consumo_bytes/", year, month, day)
    val metadataDF = readUserMetadata(url, "final.user_metadata", username, password)

    val userMetadataDF = enrichUserWithMetadata(parquetDF, metadataDF).cache()

    val bytes_antenna = computeBytesByAntenna(userMetadataDF)
    val bytes_app = computeBytesByApp(userMetadataDF)
    val bytes_email = computeBytesByEmail(userMetadataDF)
    val bytes_quota = computeBytesByQuota(userMetadataDF)


    writeToJdbc(bytes_antenna, url, "final.bytes_hourly", username, password)
    writeToJdbc(bytes_app, url, "final.bytes_hourly", username, password)
    writeToJdbc(bytes_email, url, "final.bytes_hourly", username, password)
    writeToJdbc(bytes_quota, url, "final.user_quota_limit", username, password)

    spark.close()
  }

}
