package io.keepcoding.spark.tarea.streaming
import scala.concurrent.ExecutionContext.Implicits.global
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType, TimestampType}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import scala.concurrent.{Await, Future}
import scala.concurrent.duration.Duration

object AntenaStreamingJob {

  /* Paso 1, se crea la SparkSession */
  val spark: SparkSession = SparkSession
    .builder()
    .master("local[20]")
    .appName("Tarea Final de Streaming")
    .getOrCreate()


  /* Paso 3, se implementa la lectura de datos de kafka */
  def readFromKafka(kafkaServer: String, topic: String): DataFrame = {
    spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", kafkaServer)
      .option("subscribe", topic)
      .load()
  }

  /*Paso 5 Se requiere este import para ejecuar el select con el json*/
  import spark.implicits._

  /* Paso 6. Se implementa el esquema para el proceso de parseo de los datos */
  def parserJsonData(dataFrame: DataFrame): DataFrame = {
    val jsonSchema = StructType(Seq(
      StructField("timestamp", TimestampType, nullable = false),
      StructField("id", StringType, nullable = false),
      StructField("antenna_id", StringType, nullable = false),
      StructField("bytes", IntegerType, nullable = false),
      StructField("app", StringType, nullable = false)
    ))

    //Se selecciona la informacion del data frame
    dataFrame
      .select(from_json($"value".cast(StringType), jsonSchema).as("json"))
      //se selecciona toda la información
      .select($"json.*")
  }


  /* Paso 8, ahora se trabaja en la extracción de loa metadatos de PostgreSQL */
  def readUserMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame = {
    spark
      .read
      .format("jdbc")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .load()

    //listo, en este punto ya tenemos la consulta de la tabla indicada como dataframe
  }


  /* Paso 11, ahora se procede a hacer el join entre los datos del json parseado y los metadatos */
  def enrichUserWithMetadata(antennaDF: DataFrame, metadataDF: DataFrame): DataFrame = {

    antennaDF.as("a")
      .join(metadataDF.as("b"),
        $"a.id" === $"b.id")

      //este join nos dejará duplicado el campo de id, por lo que se debe eliminar uno de ellos
      .drop($"b.id")

    //ya tenemos el join de los dataframe
  }


  /*Paso 13. Se implementan los requerimientos de análisis de bytes por antena */
  def computeBytesAntenna(dataFrame: DataFrame): DataFrame = {
    val antenna = dataFrame
      .select($"timestamp", $"antenna_id", $"bytes")
      .withWatermark("timestamp", "10 seconds") //1 minute
      .groupBy($"antenna_id", window($"timestamp", "30 seconds")) //5 minutes
      .agg(
        sum($"bytes").as("value")
      )
      .select($"window.start".as("timestamp"), $"antenna_id".as("id"), $"value")
    antenna.withColumn("type", lit("antenna_total_bytes"))
  }

  /*Paso 15. Se implementan los requerimientos de análisis de bytes por app */
  def computeBytesApp(dataFrame: DataFrame): DataFrame = {
    val antenna = dataFrame
      .select($"timestamp", $"app", $"bytes")
      .withWatermark("timestamp", "10 seconds") //1 minute
      .groupBy($"app", window($"timestamp", "30 seconds")) //5 minutes
      .agg(
        sum($"bytes").as("value")
      )
      .select($"window.start".as("timestamp"), $"app".as("id"), $"value")
    antenna.withColumn("type", lit("app_total_bytes"))
  }

  /*Paso 17. Se implementan los requerimientos de análisis de bytes por usuario */
  def computeBytesUser(dataFrame: DataFrame): DataFrame = {
    val usuario = dataFrame
      .select($"timestamp", $"id", $"bytes")
      .withWatermark("timestamp", "10 seconds") //1 minute
      .groupBy($"id", window($"timestamp", "30 seconds")) //5 minutes
      .agg(
        sum($"bytes").as("value")
      )
      .select($"window.start".as("timestamp"), $"id", $"value")
    usuario.withColumn("type", lit("user_total_bytes"))
  }

  /*Paso 19. Escribe la información en PostgreSQL */
  def writeToJdbcBytes(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Future[Unit] = Future {
    dataFrame //es tipo stream
      .writeStream
      .foreachBatch(
        (batch: DataFrame, _: Long) => {
          batch //ya es un dataframe normal
            .write
            .mode(SaveMode.Append)
            .format("jdbc")
            .option("url", jdbcURI)
            .option("dbtable", jdbcTable)
            .option("user", user)
            .option("password", password)
            .save()
        }
      )
      //para resolver el futuro
      .start()
      .awaitTermination()
  }


  /* Paso 22. Se implementa la funcion de almacenamiento en parquet*/
  def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Future[Unit] = Future {
    dataFrame
      .select(
        $"timestamp", $"id", $"antenna_id", $"bytes",$"app",
        year($"timestamp").as("year"),
        month($"timestamp").as("month"),
        dayofmonth($"timestamp").as("day"),
        hour($"timestamp").as("hour")
      )
      .writeStream
      .format("parquet")
      .option("path", s"$storageRootPath/data")
      .option("checkpointLocation", s"$storageRootPath/checkpoint")
      .partitionBy("year", "month", "day", "hour")
      .start
      .awaitTermination()
  }


  /* Paso 2, se implementa el main para ir probando las implementaciones */
  def main(args: Array[String]): Unit = {
    val ipKafka = "34.67.66.210:9092"   /* dirección y puerto del servicio Kafka*/

    /* Paso 4, se ejecuta la llamada para lectura de información de Kafka */
    val kafkaDF = readFromKafka(ipKafka, "devices")

    /* Paso 4
    kafkaDF
      .writeStream
      .format("console")
      .start()
      .awaitTermination()
    */
    /* la salida que se obtiene es la siguiente
    +----+--------------------+-------+---------+------+--------------------+-------------+
    | key|               value|  topic|partition|offset|           timestamp|timestampType|
    +----+--------------------+-------+---------+------+--------------------+-------------+
    |null|[7B 22 62 79 74 6...|devices|        0|   517|2022-10-30 15:37:...|            0|
    |null|[7B 22 62 79 74 6...|devices|        0|   518|2022-10-30 15:37:...|            0|
              ...       ...         ...
    |null|[7B 22 62 79 74 6...|devices|        0|   535|2022-10-30 15:37:...|            0|
    |null|[7B 22 62 79 74 6...|devices|        0|   536|2022-10-30 15:37:...|            0|
    +----+--------------------+-------+---------+------+--------------------+-------------+
     */

    /* Paso 7, ahora obtenemos el dato que se ha parseado a json */
    val parseDF = parserJsonData(kafkaDF)

    /* Paso 7
    parseDF
      .writeStream
      .format("console")
      .start()
      .awaitTermination()
    */
    /* la salida que se obtiene es:
    +-------------------+--------------------+--------------------+-----+--------+
    |          timestamp|                  id|          antenna_id|bytes|     app|
    +-------------------+--------------------+--------------------+-----+--------+
    |2022-10-30 16:11:56|00000000-0000-000...|00000000-0000-000...| 8073|TELEGRAM|
    |2022-10-30 16:11:56|00000000-0000-000...|00000000-0000-000...| 8567|FACETIME|
            ...       ...       ...
    |2022-10-30 16:11:56|00000000-0000-000...|22222222-2222-222...| 6694|FACEBOOK|
    |2022-10-30 16:11:56|00000000-0000-000...|22222222-2222-222...| 7948|FACEBOOK|
    +-------------------+--------------------+--------------------+-----+--------+
     */

    /* Paso 9, se definen como variables los parámetros asociados al PostgreSQL en cloud */
    val IpServer = "35.222.25.88"
    val url = s"jdbc:postgresql://$IpServer:5432/postgres"
    val username = "postgres"
    val password = "postgres"

    /* Paso 10, ahora se hace uso del dataframe del SQL */
    val metadaDF = readUserMetadata(url, "final.user_metadata", username, password)

    /*
    metadaDF
      .show()

    la salida es la siguiente:
    +--------------------+---------+-------------------+-------+
    |                  id|     name|              email|  quota|
    +--------------------+---------+-------------------+-------+
    |00000000-0000-000...|   andres|   andres@gmail.com| 200000|
    |00000000-0000-000...|     paco|     paco@gmail.com| 300000|
          ...     ...       ...
    |00000000-0000-000...|  carlota|  carlota@gmail.com| 200000|
    |00000000-0000-000...|   emilio|   emilio@gmail.com| 200000|
    +--------------------+---------+-------------------+-------+
     */

    /* Paso 12, ahora consumimos el DF enriquecido*/
    val enrichDF = enrichUserWithMetadata(parseDF, metadaDF)

    /*
    enrichDF
      .writeStream
      .option("truncate","false")
      .format("console")
      .start()
      .awaitTermination()

    La salida es la siguiente:

    +-------------------+------------------------------------+------------------------------------+-----+--------+---------+-------------------+-------+
    |timestamp          |id                                  |antenna_id                          |bytes|app     |name     |email              |quota  |
    +-------------------+------------------------------------+------------------------------------+-----+--------+---------+-------------------+-------+
    |2022-10-30 16:40:26|00000000-0000-0000-0000-000000000012|11111111-1111-1111-1111-111111111111|5456 |TELEGRAM|delicidas|delicidas@gmail.com|1000000|
    |2022-10-30 16:40:26|00000000-0000-0000-0000-000000000006|00000000-0000-0000-0000-000000000000|8257 |SKYPE   |luis     |luis@gmail.com     |200000 |
        ...     ...     ...
    |2022-10-30 16:40:26|00000000-0000-0000-0000-000000000016|22222222-2222-2222-2222-222222222222|832  |FACEBOOK|maria    |maria@gmail.com    |1000000|
    |2022-10-30 16:40:26|00000000-0000-0000-0000-000000000003|00000000-0000-0000-0000-000000000000|5329 |FACETIME|juan     |juan@gmail.com     |100000 |
    +-------------------+------------------------------------+------------------------------------+-----+--------+---------+-------------------+-------+
     */

    /* Paso 14, obtenemos el dataframe de los bytes consumidos por antena */
    val bytes_antenna = computeBytesAntenna(enrichDF)

    /*
    bytes_antenna
      .writeStream
      .option("truncate","false")
      .format("console")
      .start()
      .awaitTermination()
    */
    /* la salida es:
    +-------------------+------------------------------------+-----+-------------------+
    |timestamp          |id                                  |value|type               |
    +-------------------+------------------------------------+-----+-------------------+
    |2022-10-30 19:52:00|11111111-1111-1111-1111-111111111111|16374|antenna_bytes_total|
    |2022-10-30 19:52:00|00000000-0000-0000-0000-000000000000|56296|antenna_bytes_total|
    |2022-10-30 19:52:00|22222222-2222-2222-2222-222222222222|21637|antenna_bytes_total|
    +-------------------+------------------------------------+-----+-------------------+
     */

  /* Paso 16, obtenemos el dataframe de los bytes consumidos por app */
  val bytes_app = computeBytesApp(enrichDF)
    /*
    bytes_app
      .writeStream
      .option("truncate", "false")
      .format("console")
      .start()
      .awaitTermination()
      */
    /*
    +-------------------+--------+-----+---------------+
    |timestamp          |id      |value|type           |
    +-------------------+--------+-----+---------------+
    |2022-10-30 20:00:00|FACETIME|13943|app_bytes_total|
    |2022-10-30 20:00:00|SKYPE   |20457|app_bytes_total|
    |2022-10-30 20:00:00|TELEGRAM|17452|app_bytes_total|
    |2022-10-30 20:00:00|FACEBOOK|43709|app_bytes_total|
    +-------------------+--------+-----+---------------+
     */

    /* Paso 18, obtenemos el dataframe de los bytes consumidos por usuario */
    val bytes_user = computeBytesUser(enrichDF)
    /*
    bytes_user
      .writeStream
      .option("truncate", "false")
      .format("console")
      .start()
      .awaitTermination()

    +-------------------+------------------------------------+-----+----------------+
    |timestamp          |id                                  |value|type            |
    +-------------------+------------------------------------+-----+----------------+
    |2022-10-30 20:11:30|00000000-0000-0000-0000-000000000013|7746 |user_total_bytes|
    |2022-10-30 20:11:30|00000000-0000-0000-0000-000000000019|204  |user_total_bytes|
            ...     ...     ...
    |2022-10-30 20:11:30|00000000-0000-0000-0000-000000000014|6055 |user_total_bytes|
    |2022-10-30 20:11:30|00000000-0000-0000-0000-000000000012|6080 |user_total_bytes|
    +-------------------+------------------------------------+-----+----------------+
     */

    /* Paso 20, ahora enviamos la información al SQL de App*/
    val jdbcFutureApp = writeToJdbcBytes(bytes_app, url, "final.bytes", username, password)

    /* Paso 21, ahora enviamos la información al SQL de App*/
    val jdbcFutureUser = writeToJdbcBytes(bytes_user, url, "final.bytes", username, password)
    val jdbcFutureAntenna = writeToJdbcBytes(bytes_antenna, url, "final.bytes", username, password)

    /* Paso 23. Se invoca el proceso de escritura en parquet */
    val storage01 = writeToStorage(parseDF, "/tmp/consumo_bytes/")


    Await.result(Future.sequence(Seq(jdbcFutureApp, jdbcFutureUser, jdbcFutureAntenna, storage01)), Duration.Inf)
  }
}
